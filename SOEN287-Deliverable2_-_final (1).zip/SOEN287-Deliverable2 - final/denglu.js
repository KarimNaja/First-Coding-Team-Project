//设置基本属性
let http = require('http');
let url = require('url');
let fs = require('fs');
let querystring = require('querystring');
let mysql = require('MySQL');
const { title, constrainedMemory } = require('process');
const { text } = require('body-parser');
let port=3007;
//创建数据库接口
let connection = mysql.createConnection({
    host: 'localhost',
    port:'3306',
    user: 'root',
    password: '',
    database: 'test',
    multipleStatements:true
});
//连接mysql数据库
connection.connect(function(err) {
  if (err) {
    return console.error('error: ' + err.message);
  }
  console.log('Connected to the MySQL server.');
});
//设置所需变量
var users,a,b,c,d,softwares,serial,bsoftwares,suiji,providers,uli,sold,myso,me,pe,mail; 
//创建服务器
var i=0;
http.createServer((req,res)=>{
	let path,get,post;

	if(req.method=='GET'){
		let {pathname,query} = url.parse(req.url,true)
    console.log(req.url,"------------1");
    console.log(pathname,"-------------2");
    console.log(query,"-------------3");
		path = pathname;
		get = query;
    i++;console.log(i,"--------------",path,JSON.stringify(get));
		complete();
	}else if (req.method=='POST') {
		let arr = [];
		path = req.url;
		req.on('data',buffer=>{
      console.log(buffer,"------------7");
			arr.push(buffer);
		})
    console.log(arr,"------------4");
		req.on('end',()=>{
			post = querystring.parse(Buffer.concat(arr).toString());
            console.log(post);
			complete();
      console.log(arr,"------------8");
      console.log(post,"------------9");
		})
    console.log(req.url,"------------5");
    console.log(arr,"------------6");
	}
  //调用complete()函数判断方法是get还是post
    function complete(){
        if (path == '/ulogin') {
            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            })
            let {username,password} = post;
            
            sqlstring = `select * From users where username='${username}' and password='${password}';`;
            connection.query(sqlstring, function (err, result) {
                /*
                let resultJson = JSON.stringify(result);
                let dataJson = JSON.parse(resultJson);
                */
                users=result;


            if(err){
              console.log('[SELECT ERROR] - ', err.message);
                res.end(JSON.stringify({
                status:2,
                statusMsg:'Username or password wrong！'
            }))
              return;
            }
            else if(result.length>0){
                //res.status=1;
                res.end(JSON.stringify({
                    status:1,
                    statusMsg:'Log in succes！'
                }))

            }
            else{
                
                  res.end(JSON.stringify({
                  status:2,
                  statusMsg:'Username or password wrong！'
              }))
                return;
              }   
                
              res.end();
              console.log('3--------------------------SELECT---------------------------');
              console.log('SELECT - ', users);
              console.log('------------------------------------------------------------\n\n');
            });   
        }       //   '/ulogin'  

        else if (path == '/uinfo') {
            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            })

            sqlstring = ` select s1.username,s2.name,s2.version,s4.username,s2.serialnumber,s2.qufen,s2.activedate,
            s2.validuntil,s2.validation from
            users as s1 join sells as s2 on s1.username = s2.purchaseby 
            join software as s3 on s3.name=s2.name and s3.version=s2.version
            join providers as s4 on s4.username=s3.providername
            where s1.username='${users[0].username}';`;
            
            connection.query(sqlstring, function (err, result) {
                /*
                let resultJson = JSON.stringify(result);
                let dataJson = JSON.parse(resultJson);
                */
                softwares=result;


            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }
                
            res.end(JSON.stringify({
                status:1,
                statusMsg:'Here your personal info！',
                data:{
                        users,
                        softwares
                }
            }))
              console.log('4--------------------------SELECT---------------------------');
              console.log('SELECT - ', softwares);
              console.log('------------------------------------------------------------\n\n');
            });
            
        }       //   '/uinfo'  

        else if (path == '/add') {
            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            })
            let {username,name,password,email,telephone,address} = post;
            console.log("POST--",post);
            sqlstring = `insert into users values ("${username}","${password}","${name}","${email}","${telephone}","${address}",0);`;
//判断是否为空
     if(!(username.match(/^\s+$/)||username==""||password.match(/^\s+$/)||password==""||name.match(/^\s+$/)||name=="")){
       //判断是否与管理员相同
            if(!(username=="1000"||username=="1001")){
            connection.query(sqlstring, function (err, result) {
                /*
                let resultJson = JSON.stringify(result);
                let dataJson = JSON.parse(resultJson);
                */

            if(err){
              console.log('[SELECT ERROR] - ', err.message);
                res.end(JSON.stringify({
                status:2,
                statusMsg:'username is already existe！'
            }))
              return;
            }

            else{
                
                  res.end(JSON.stringify({
                  status:1,
                  statusMsg:'Good ！'
              }))
                return;
              }   
            });  
            
          }          else{
            res.end(JSON.stringify({
              status:2,
              statusMsg:'username can not be 1000 or 1001'
          }))
            return;
          }
        }

          else{
            res.end(JSON.stringify({
              status:2,
              statusMsg:'Input at least your username and password and your name.'
          }))
            return;
          }
          
        }       //  '/add'

        else if (path == '/shop') {
            sqlstring1 = `select s1.name,s1.version,s1.price,s1.renew,s2.name as nm,s2.username as kfs from 
            software as s1 join providers as s2 on s1.providername=s2.username;`;
            
            //sqlstring2 = `select serialnumber from sells`;
            connection.query(sqlstring1, function (err, result) {
                /*
                let resultJson = JSON.stringify(result);
                let dataJson = JSON.parse(resultJson);
                */
                bsoftwares=result;


            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }


              console.log('1--------------------------SELECT---------------------------');
              console.log('SELECT - R0', result);
              console.log('------------------------------------------------------------\n\n');
            });

            sqlstring2 = `select serialnumber from sells`;
            connection.query(sqlstring2, function (err, result) {
                /*
                let resultJson = JSON.stringify(result);
                let dataJson = JSON.parse(resultJson);
                */
                suiji=result;


            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }
            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            }) 

            res.end(JSON.stringify({
                status:1,
                statusMsg:'Here you are！',
                data:{
                        users,
                        bsoftwares,
                        suiji
                }
            }))
              console.log('8--------------------------SELECT---------------------------');
              console.log('SELECT - R1', result);
              console.log('------------------------------------------------------------\n\n');
            });

            
        }       //   '/shop'  

        else if (path == '/thissoftware') {
            let {serialnumber} = get;
            console.log(`序列号：`,{serialnumber},get);
            sqlstring =` select * from sells as s1 join software as s2 on s1.name=s2.name and s1.version=s2.version where s1.serialnumber=${serialnumber};`; 
            
            connection.query(sqlstring, function (err, result) {
                serial=result;
            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }
                
            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            })

            res.end(JSON.stringify({
                status:1,
                statusMsg:'Your software！',
                data:{serial
                    ,users
                }
                
            }))
              console.log('5--------------------------SELECT---------------------------');
              console.log('SELECT - ', serial,users);
              console.log('------------------------------------------------------------\n\n');
            });           
        }        //   '/thissoftware'  

        else if(path=='/renew'){
            let {activedate,validuntil,validation,sold,fro,too,reading,date,title,text} = post;
            console.log(post);
            sqlstring = `update sells set activedate="${activedate}",validuntil="${validuntil}",validation=${validation} where serialnumber=${serial[0].serialnumber};`;
            
            connection.query(sqlstring, function (err, result) {
                a=result;
            if(err){
              console.log('[SELECT ERROR] - gengxin', err.message);

              return;
            }


              console.log('6--------------------------SELECT---------------------------');
              console.log('SELECT - ', a);
              console.log('------------------------------------------------------------\n\n');
            });

            //***** **********************************-------------

            sqlstring = `insert into mail values("${fro}","${too}","${reading}","${date}","${title}","${text}")`;
            
            connection.query(sqlstring, function (err, result) {
                a=result;
            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }


              console.log('6--------------------------SELECT---------------------------');
              console.log('SELECT - ', a);
              console.log('------------------------------------------------------------\n\n');
            });

            //******************** --------------

            sqlstring = `update users set sold=${sold} where username='${users[0].username}';`;
            
            connection.query(sqlstring, function (err, result) {
                b=result;
            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }
            else{
                users[0].sold=sold;
                console.log("///////////////////////",users[0].sold);
            }    

            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            })
            
            res.end(JSON.stringify({
                status:1,
                statusMsg:'Your software！',
                data:{a,b,users}
                
            }))
              console.log('7--------------------------SELECT---------------------------');
              console.log('SELECT - ', b,users);
              console.log('------------------------------------------------------------\n\n');
            });
        }           //   '/renew'  

        else if(path=='/bs'){
            let {name,version,purchaseby,serialnumber,purchasedate,activedate,validation,validuntil,qufen,m,kfs} = post;
            console.log(post);
            sqlstring = `insert into sells values ("${name}","${version}","${purchaseby}","${serialnumber}","${purchasedate}","${activedate}","${validation}","${validuntil}","${qufen}");`;
            
            connection.query(sqlstring, function (err, result) {
                c=result;
            if(err){
              console.log('[SELECT ERROR] ', err.message);

              return;
            }

              console.log('9--------------------------SELECT---------------------------');
              console.log('SELECT - ', c);
              console.log('------------------------------------------------------------\n\n');
            });

            //购买后发邮件-----------------------------------------
            sqlstring = `insert into mail values ("${purchaseby}","${kfs}",false,"${purchasedate}","${serialnumber} sold","The user with ID: ${purchaseby} bought ${name} ${version} at ${purchasedate}");`;
            
            connection.query(sqlstring, function (err, result) {
                
            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }


              console.log('17--------------------------SELECT---------------------------');
              console.log('SELECT - ', c);
              console.log('------------------------------------------------------------\n\n');
            });
            //购买后发邮件--------------------------结束

            //购买后发邮件-----------------------------------------
            sqlstring = `insert into mail values ("${kfs}","${purchaseby}",false,"${purchasedate}","${qufen} bought","Hi, user:${purchaseby}. You bought ${name} ${version} at ${purchasedate} with serialnumber: ${serialnumber}");`;
            
            connection.query(sqlstring, function (err, result) {
                
            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }


              console.log('19--------------------------SELECT---------------------------');
              console.log('SELECT - ', c);
              console.log('------------------------------------------------------------\n\n');
            });
            //购买后发邮件--------------------------结束

            sqlstring = `update users set sold=${m} where username='${users[0].username}';`;
            
            connection.query(sqlstring, function (err, result) {
                d=result;
            if(err){
              console.log('[SELECT ERROR] - mai', err.message);

              return;
            }
            else{
                users[0].sold=m;
                console.log("///////////////////////",users[0].sold);
            }    

            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            })
            
            res.end(JSON.stringify({
                status:1,
                statusMsg:'Bought ！',
                data:{c,d,users}
                
            }))
              console.log('10--------------------------SELECT---------------------------');
              console.log('SELECT - ', b,users);
              console.log('------------------------------------------------------------\n\n');
            });
        }            //   '/bs'  

        else if(path=='/uchange'){
            let{password,name,email,telephone,address}=post;
            console.log(post);
            sqlstring=`update users set password="${password}",name="${name}",email="${email}",telephone="${telephone}",address="${address}" where username="${users[0].username}";`
                    
            connection.query(sqlstring, function (err, result) {
                
            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }
            else{
                users[0].password=password;
                users[0].name=name;
                users[0].email=email;
                users[0].telephone=telephone;
                users[0].address=address;
                console.log("///////////////////////",users[0]);
            }    

            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            })
            
            res.end(JSON.stringify({
                status:1,
                statusMsg:'Information changed succesful！',
                data:{users}
                
            }))
              console.log('11--------------------------SELECT---------------------------');
              console.log('SELECT - ',users);
              console.log('------------------------------------------------------------\n\n');
            });
        }            //   '/uchange'  

        else if(path=='/umail'){
          res.writeHead(200,{
              "Content-Type":'text/plain;chartset=utf-8'
          })

          sqlstring = ` select * from mail where too='${users[0].username}';`;
          
          connection.query(sqlstring, function (err, result) {
              /*
              let resultJson = JSON.stringify(result);
              let dataJson = JSON.parse(resultJson);
              */
              me=users[0];
              //pe=providers[0];
              mail=result;

          if(err){
            console.log('[SELECT ERROR] - ', err.message);

            return;
          }
              
          res.end(JSON.stringify({
              status:1,
              statusMsg:'Mails here！',
              data:{
                     me,mail
              }
          }))
            console.log('22--------------------------SELECT---------------------------');
            console.log('SELECT - ', me,mail);
            console.log('------------------------------------------------------------\n\n');
          });
          
      }             //   '/umail' 

        else if(path=='/dm'){

          let {title,text}=post;

          sqlstring = `delete from mail where title="${title}" and text="${text}";`;
            
          connection.query(sqlstring, function (err, result) {
              //d=result;
          if(err){
            console.log('[SELECT ERROR] - ', err.message);

            return;
          }
    

          res.writeHead(200,{
              "Content-Type":'text/plain;chartset=utf-8'
          })
          
          res.end(JSON.stringify({
              status:1,
              statusMsg:'Mail deleted！',
              data:{c,d,users}
              
          }))
            console.log('4444--------------------------SELECT---------------------------');
            console.log('SELECT - ', mail);
            console.log('------------------------------------------------------------\n\n');
          });



        }            //   '/dm' 

        else if(path=='/gaim'){

          let {title,text}=post;

          sqlstring = `update mail set reading = true where title="${title}" and text="${text}";`;
            
          connection.query(sqlstring, function (err, result) {
              //d=result;
          if(err){
            console.log('[SELECT ERROR] - ', err.message);

            return;
          }
    

          res.writeHead(200,{
              "Content-Type":'text/plain;chartset=utf-8'
          })
          
          res.end(JSON.stringify({
              status:1,
              statusMsg:'Mail is readed！',
              data:{c,d,users}
              
          }))
            console.log('3333--------------------------SELECT---------------------------');
            console.log('SELECT - ', mail);
            console.log('------------------------------------------------------------\n\n');
          });

          

        }            //   '/gaim' 


        else if(path=='/Plogin') {
            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            })
            let {username,password} = post;
            
            sqlstring = `select * From providers where username=${username} and password=${password}`;
            connection.query(sqlstring, function (err, result) {
                /*
                let resultJson = JSON.stringify(result);
                let dataJson = JSON.parse(resultJson);
                */
                providers=result;


            if(err){
              console.log('[SELECT ERROR] - ', err.message);
                res.end(JSON.stringify({
                status:2,
                statusMsg:'Wrong username or password！'
            }))
              return;
            }
            else if(result.length>0){
                //res.status=1;
                res.end(JSON.stringify({
                    status:1,
                    statusMsg:'Succes log in！'
                }))

            }
            else{
                
                  res.end(JSON.stringify({
                  status:2,
                  statusMsg:'Wrong username or password！'
              }))
                return;
              }   
                
              res.end();
              console.log('12--------------------------SELECT---------------------------');
              console.log('SELECT - ', providers);
              console.log('------------------------------------------------------------\n\n');
            });   
        }       //   '/Plogin'  

        else if(path=='/pinfo'){
            res.end(JSON.stringify({
                status:1,
                statusMsg:'Your info！',
                data:{
                        providers
                }
            }))
        }            //   '/pinfo'  

        else if(path=='/pchange'){
            let{password,name,email,telephone,address}=post;
            console.log(post);
            sqlstring=`update providers set password="${password}",name="${name}",email="${email}",telephone="${telephone}",address="${address}" where username=${providers[0].username};`
                    
            connection.query(sqlstring, function (err, result) {
                
            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }
            else{
                providers[0].password=password;
                providers[0].name=name;
                providers[0].email=email;
                providers[0].telephone=telephone;
                providers[0].address=address;
                console.log("///////////////////////",providers[0]);
            }    

            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            })
            
            res.end(JSON.stringify({
                status:1,
                statusMsg:'Information changed！',
                data:{providers}
                
            }))
              console.log('13--------------------------SELECT---------------------------');
              console.log('SELECT - ',providers);
              console.log('------------------------------------------------------------\n\n');
            });
        }            //   '/pchange'  

        else if(path=='/userlist'){

            connection.query(`select * from users`, function (err, result) {

                uli=result;

            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }});
            
            connection.query(`select * from sells`, function (err, result) {

                sold=result;

            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }
            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            }) 

            res.end(JSON.stringify({
                status:1,
                statusMsg:'Here are all users！',
                data:{
                       uli,
                       sold
                }
            }))
              console.log('13--------------------------SELECT---------------------------');
              console.log('SELECT - R1', result);
              console.log('------------------------------------------------------------\n\n');
            });
        }            //   '/userlist'  

        else if(path=='/delet'){

            let{username}=post;
            
            connection.query(`delete from users where username='${username}';`, function (err, result) {

                //sold=result;

            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }
            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            }) 

            res.end(JSON.stringify({
                status:1,
                statusMsg:'Deleted！',
                data:{
                       uli,
                       sold
                }
            }))
              console.log('14--------------------------SELECT---------------------------');
              console.log('SELECT - R1', result);
              console.log('------------------------------------------------------------\n\n');
            });
        }              //      delet 

        else if(path=='/pgaiu'){
            let{username,password,name,email,telephone,address,sold}=post;
            console.log(post);
            if(!(username.match(/^\s+$/)||username==""||password.match(/^\s+$/)||password==""||name.match(/^\s+$/)||name==""||isNaN(parseFloat(sold)))){
            sqlstring=`update users set password="${password}",name="${name}",email="${email}",telephone="${telephone}",address="${address}",sold=${sold} where username='${username}';`
                    
            connection.query(sqlstring, function (err, result) {
                
            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }

            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            })
            
            res.end(JSON.stringify({
                status:1,
                statusMsg:'Edited！',
                data:{result}
                
            }))
              console.log('14--------------------------SELECT---------------------------');
              console.log('SELECT - ');
              console.log('------------------------------------------------------------\n\n');
            });}
            else{
              res.end(JSON.stringify({
                status:2,
                statusMsg:'invalid input'
            }))
              return;
            }

        }            //   '/pgaiu'  

        else if(path=='/associate'){

            let {name,version,purchaseby,serialnumber,purchasedate,activedate,validation,validuntil,qufen} = post;
            console.log(post);

            sqlstring = `insert into mail values ("${providers[0].username}","${purchaseby}",false,"${purchasedate}","${qufen} for free 1 year","Hi, user:${purchaseby}. I give you ${name} ${version} at ${purchasedate} with serialnumber: ${serialnumber} ,please active it with the correspond 4 letters.");`;
            
            connection.query(sqlstring, function (err, result) {
                
            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }


              console.log('20--------------------------SELECT---------------------------');
              console.log('SELECT - ');
              console.log('------------------------------------------------------------\n\n');
            });

            sqlstring = `insert into sells values ("${name}","${version}","${purchaseby}","${serialnumber}","${purchasedate}","${activedate}","${validation}","${validuntil}","${qufen}");`;
            
            connection.query(sqlstring, function (err, result) {
                
            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }

            res.writeHead(200,{
                "Content-Type":'text/plain;chartset=utf-8'
            })
            
            res.end(JSON.stringify({
                status:1,
                statusMsg:'Associated！',
                data:{result}
                
            }))


              console.log('19--------------------------SELECT---------------------------');
              console.log('SELECT - ');
              console.log('------------------------------------------------------------\n\n');
            });



        }            //   '/associate' 

        else if(path=='/solist'){

            connection.query(`select * from users`, function (err, result) {

                uli=result;

            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }});

            connection.query(`select * from sells`, function (err, result) {

                sold=result;

            if(err){
              console.log('[SELECT ERROR] - ', err.message);

              return;
            }});
            //me=providers[0].username;
            sqlstring=`select * from software where providername=${providers[0].username}`;

            connection.query(sqlstring, function(err,result){
                if(err){
                    console.log('[SELECT ERROR] - ', err.message);
                    return;
                  }
                  myso=result;     
                  res.writeHead(200,{
                      "Content-Type":'text/plain;chartset=utf-8'
                  })
                  
                  res.end(JSON.stringify({
                      status:1,
                      statusMsg:'Software list ！',
                      data:{myso,uli,sold}
                      
                  }))
                    console.log('15--------------------------SELECT---------------------------');
                    console.log('SELECT - ',result);
                    console.log('------------------------------------------------------------\n\n');

            });

        }            //   '/solist'  

        else if(path=='/pmail'){
          res.writeHead(200,{
              "Content-Type":'text/plain;chartset=utf-8'
          })

          sqlstring = ` select * from mail where too=${providers[0].username}`;
          
          connection.query(sqlstring, function (err, result) {

              pe=providers[0];
              mail=result;

          if(err){
            console.log('[SELECT ERROR] - ', err.message);

            return;
          }
              
          res.end(JSON.stringify({
              status:1,
              statusMsg:'Your mails here！',
              data:{
                     pe,mail
              }
          }))
            console.log('22--------------------------SELECT---------------------------');
            console.log('SELECT - ', pe,mail);
            console.log('------------------------------------------------------------\n\n');
          });
          
      }            //   '/pmail' 

        else if(path=='/gaishei'){

          let {username}=get;
          console.log(username);
          sqlstring=`select * from users where username=${username}`;
          connection.query(sqlstring, function (err, result) {
            /*
            let resultJson = JSON.stringify(result);
            let dataJson = JSON.parse(resultJson);
            */
            let zhege=result;


        if(err){
          console.log('[SELECT ERROR] - ', err.message);

          return;
        }
            
        res.end(JSON.stringify({
            status:1,
            statusMsg:'User personal info！',
            data:{
                    
                    zhege
            }
        }))
          console.log('34--------------------------SELECT---------------------------');
          console.log('SELECT - ', zhege);
          console.log('------------------------------------------------------------\n\n');
        });

      }

        //以上路径全都不符合的时候或找不到服务器上所拥有的HTML文件时返回404
        else{
            fs.readFile(`./${path}`,(err,data)=>{              
                if(err){
                    res.writeHead(404, {"Content-Type": "text/html"});
                    res.end('<h1><br>404<br>Page Not Found</h1>');
                }else{
                  console.log("8888888888888888888");
                    res.end(data);
                }
            })
        }
    };
}).listen(port);
console.log(`http://localhost:${port}/index.html`);
